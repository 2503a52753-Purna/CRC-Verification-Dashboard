"""
================================================================================
Flask Web Application for PythonAnywhere: Attendance CRC Dashboard
--------------------------------------------------------------------------------
Built strictly using the fundamental CRC bitwise XOR algorithm without any
external CRC libraries. Strictly follows all 3 modes and rules without bit-flipping.
================================================================================
"""

import os
import io
import datetime
from flask import Flask, render_template, request, jsonify, Response

app = Flask(__name__)

# -----------------------------------------------------------------------------
# CORE ALGORITHMS (EXACT USER SPECIFIED CODE)
# -----------------------------------------------------------------------------
def crc(data, gen):
    data = list(data)

    for i in range(len(data) - len(gen) + 1):
        if data[i] == "1":
            for j in range(len(gen)):
                data[i + j] = str(int(data[i + j]) ^ int(gen[j]))

    return "".join(data[-(len(gen) - 1) :])


def text_to_binary(text):
    # Converts text to 8-bit ASCII binary
    return "".join(format(ord(char), "08b") for char in text)


# -----------------------------------------------------------------------------
# SAMPLE DATASETS
# -----------------------------------------------------------------------------
SAMPLE_CSV_ORIGINAL = (
    "StudentID,Name,Course,Date,Status\n"
    "101,Aarav Sharma,Computer Networks,2026-09-11,Present\n"
    "102,Bhavna Patel,Computer Networks,2026-09-11,Present\n"
    "103,Chirag Reddy,Computer Networks,2026-09-11,Absent\n"
    "104,Divya Rao,Computer Networks,2026-09-11,Present\n"
    "105,Eshwar Kumar,Computer Networks,2026-09-11,Present\n"
)

SAMPLE_CSV_TAMPERED = (
    "StudentID,Name,Course,Date,Status\n"
    "101,Aarav Sharma,Computer Networks,2026-09-11,Present\n"
    "102,Bhavna Patel,Computer Networks,2026-09-11,Present\n"
    "103,Chirag Reddy,Computer Networks,2026-09-11,Present\n"
    "104,Divya Rao,Computer Networks,2026-09-11,Present\n"
    "105,Eshwar Kumar,Computer Networks,2026-09-11,Present\n"
)

SAMPLE_CSV_DELETED = (
    "StudentID,Name,Course,Date,Status\n"
    "101,Aarav Sharma,Computer Networks,2026-09-11,Present\n"
    "102,Bhavna Patel,Computer Networks,2026-09-11,Present\n"
    "103,Chirag Reddy,Computer Networks,2026-09-11,Absent\n"
    "104,Divya Rao,Computer Networks,2026-09-11,Present\n"
)


# -----------------------------------------------------------------------------
# ROUTES
# -----------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/mode1", methods=["POST"])
def api_mode1():
    req = request.get_json(force=True)
    gen = req.get("gen", "100000111").strip()
    data = req.get("data", "100100").strip()
    received_codeword = req.get("received_codeword", "").strip()

    if not gen or len(gen) < 2 or not set(gen).issubset({"0", "1"}):
        return jsonify({"error": "Invalid generator polynomial"}), 400

    crc_len = len(gen) - 1

    # Sender Calculations
    new_data = data + "0" * crc_len
    sender_crc = crc(new_data, gen) if set(data).issubset({"0", "1"}) else ""
    codeword = data + sender_crc if sender_crc else ""

    # Receiver Calculations
    remainder = ""
    is_valid = False
    extracted_data = ""

    if received_codeword and set(received_codeword).issubset({"0", "1"}):
        if len(received_codeword) >= len(gen):
            remainder = crc(received_codeword, gen)
            is_valid = (int(remainder, 2) == 0)
            if is_valid:
                extracted_data = received_codeword[:-crc_len]

    return jsonify({
        "gen": gen,
        "crc_len": crc_len,
        "padded_data": new_data,
        "sender_crc": sender_crc,
        "codeword": codeword,
        "remainder": remainder,
        "is_valid": is_valid,
        "extracted_data": extracted_data,
    })


@app.route("/api/mode2", methods=["POST"])
def api_mode2():
    req = request.get_json(force=True)
    gen = req.get("gen", "100000111").strip()
    sender_text = req.get("sender_text", "")
    receiver_text = req.get("receiver_text", "")

    if not gen or len(gen) < 2 or not set(gen).issubset({"0", "1"}):
        return jsonify({"error": "Invalid generator polynomial"}), 400

    crc_len = len(gen) - 1

    sender_binary = text_to_binary(sender_text)
    sender_crc = crc(sender_binary + "0" * crc_len, gen) if sender_binary else "0" * crc_len

    receiver_binary = text_to_binary(receiver_text)
    receiver_crc = crc(receiver_binary + "0" * crc_len, gen) if receiver_binary else "0" * crc_len

    return jsonify({
        "gen": gen,
        "crc_len": crc_len,
        "sender_binary": sender_binary,
        "sender_crc": sender_crc,
        "receiver_binary": receiver_binary,
        "receiver_crc": receiver_crc,
        "is_match": (sender_crc == receiver_crc),
    })


@app.route("/api/mode3", methods=["POST"])
def api_mode3():
    req = request.get_json(force=True)
    gen = req.get("gen", "100000111").strip()
    sender_content = req.get("sender_content", SAMPLE_CSV_ORIGINAL)
    receiver_content = req.get("receiver_content", SAMPLE_CSV_ORIGINAL)

    if not gen or len(gen) < 2 or not set(gen).issubset({"0", "1"}):
        return jsonify({"error": "Invalid generator polynomial"}), 400

    crc_len = len(gen) - 1

    sender_binary = text_to_binary(sender_content)
    sender_crc = crc(sender_binary + "0" * crc_len, gen) if sender_binary else "0" * crc_len

    receiver_binary = text_to_binary(receiver_content)
    receiver_crc = crc(receiver_binary + "0" * crc_len, gen) if receiver_binary else "0" * crc_len

    return jsonify({
        "gen": gen,
        "crc_len": crc_len,
        "sender_crc": sender_crc,
        "receiver_crc": receiver_crc,
        "is_match": (sender_crc == receiver_crc),
    })


@app.route("/api/download_report", methods=["POST"])
def api_download_report():
    req = request.get_json(force=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sender_name = req.get("sender_name", "sample_attendance_original.csv")
    receiver_name = req.get("receiver_name", "sample_attendance_original.csv")
    standard = req.get("standard", "CRC-8")
    gen = req.get("gen", "100000111")
    sender_crc = req.get("sender_crc", "")
    receiver_crc = req.get("receiver_crc", "")
    is_match = (sender_crc == receiver_crc)

    report_lines = [
        "Audit Timestamp,Original File,Audited File,CRC Standard,Generator,Original CRC,Audited CRC,Audit Verdict,Details",
        f'"{timestamp}","{sender_name}","{receiver_name}","{standard}","{gen}","{sender_crc}","{receiver_crc}","{"PASS (Authentic)" if is_match else "FAIL (Tampered)"}","{"File content 100% identical." if is_match else "Discrepancy in file content or missing rows."}"'
    ]
    csv_output = "\n".join(report_lines)

    return Response(
        csv_output,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=crc_audit_report_{standard.lower()}.csv"}
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
