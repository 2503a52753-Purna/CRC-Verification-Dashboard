# ==============================================================================
# PythonAnywhere WSGI Configuration File
# ------------------------------------------------------------------------------
# In your PythonAnywhere Web Tab, point the WSGI configuration file to this file
# or copy-paste these lines into your PythonAnywhere WSGI file.
# ==============================================================================

import sys
import os

# Add project root directory to Python path
project_home = os.path.dirname(os.path.abspath(__file__))
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Import the Flask application object as 'application' (WSGI standard)
from flask_app import app as application
